module.exports = {
  MONGODB_URI: 'mongodb://sungsu:sungsu@ds139969.mlab.com:39969/horizons-sungsu'
}
