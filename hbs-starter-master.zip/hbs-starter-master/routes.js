"use strict";

// Routes, with inline controllers for each route.
var express = require('express');
var router = express.Router();
var Todo = require('./models').Todo;

router.get('/', function(req, res) {
  res.render('todos')
});


module.exports = router;