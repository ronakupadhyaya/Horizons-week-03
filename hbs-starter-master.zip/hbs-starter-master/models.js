
"use strict";

var mongoose = require('mongoose');

var Todo = mongoose.model('Todo', {

});

module.exports = {
  Todo: Todo
}