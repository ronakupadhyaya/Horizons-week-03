module.exports = {
  MONGODB_URI: 'mongodb://lisa:lisa@ds139869.mlab.com:39869/lisa-facebook'
}
