"use strict";

// Database configuration

module.exports = {
  'url' : 'mongodb://localhost/horizonstarter'
};
