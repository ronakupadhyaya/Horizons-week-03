# Day 2 exercises

## Morning Videos & Individual Exercises

1. [Videos and Exercises](examples/README.md)

## Pair programming exercises

1. [Web 1.0 Guestbook](guestbook/README.md)
1. [Bonus: Trello CSV Import Export](trello-csv/README.md)
